import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/model/product.dart';
import '../../providers/product_provider.dart';

/// Used for both "Add" (product == null) and "Edit".
class ProductFormScreen extends StatefulWidget {
  const ProductFormScreen({super.key, this.product});

  final Product? product;

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final _title = TextEditingController(text: widget.product?.title);
  late final _description =
      TextEditingController(text: widget.product?.description);
  late final _brand = TextEditingController(text: widget.product?.brand);
  late final _category = TextEditingController(text: widget.product?.category);
  late final _price =
      TextEditingController(text: widget.product?.price.toString());
  late final _stock =
      TextEditingController(text: widget.product?.stock.toString());
  late final _image = TextEditingController(text: widget.product?.thumbnail);
  bool _saving = false;

  bool get _isEdit => widget.product != null;

  @override
  void dispose() {
    for (final c in [_title, _description, _brand, _category, _price, _stock, _image]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _required(String? v) =>
      (v == null || v.trim().isEmpty) ? 'This field is required' : null;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    final provider = context.read<ProductProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    final img = _image.text.trim();
    final price = double.parse(_price.text.trim());
    final stock = int.parse(_stock.text.trim());

    final Product result;
    if (_isEdit) {
      final old = widget.product!;
      result = old.copyWith(
        title: _title.text.trim(),
        description: _description.text.trim(),
        brand: _brand.text.trim(),
        category: _category.text.trim(),
        price: price,
        stock: stock,
        thumbnail: img,
        images: img == old.thumbnail
            ? old.images
            : (img.isEmpty ? <String>[] : [img]),
        isEdited: true,
      );
      await provider.updateProduct(result);
    } else {
      result = Product(
        id: -DateTime.now().millisecondsSinceEpoch, // negative = local item
        title: _title.text.trim(),
        description: _description.text.trim(),
        brand: _brand.text.trim(),
        category: _category.text.trim(),
        price: price,
        stock: stock,
        thumbnail: img,
        images: img.isEmpty ? const [] : [img],
        isLocal: true,
      );
      await provider.addProduct(result);
    }

    messenger.showSnackBar(
      SnackBar(content: Text(_isEdit ? 'Product updated' : 'Product added')),
    );
    navigator.pop(result);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Edit product' : 'Add product')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                TextFormField(
                  controller: _title,
                  decoration: const InputDecoration(labelText: 'Title'),
                  textInputAction: TextInputAction.next,
                  validator: _required,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _description,
                  decoration: const InputDecoration(labelText: 'Description'),
                  maxLines: 3,
                  validator: _required,
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _brand,
                        decoration: const InputDecoration(labelText: 'Brand'),
                        textInputAction: TextInputAction.next,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                        controller: _category,
                        decoration: const InputDecoration(labelText: 'Category'),
                        textInputAction: TextInputAction.next,
                        validator: _required,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _price,
                        decoration:
                            const InputDecoration(labelText: 'Price (\$)'),
                        keyboardType: const TextInputType.numberWithOptions(
                            decimal: true),
                        validator: (v) {
                          final n = double.tryParse(v?.trim() ?? '');
                          return (n == null || n < 0) ? 'Enter a valid price' : null;
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                        controller: _stock,
                        decoration: const InputDecoration(labelText: 'Stock'),
                        keyboardType: TextInputType.number,
                        validator: (v) {
                          final n = int.tryParse(v?.trim() ?? '');
                          return (n == null || n < 0) ? 'Enter a valid number' : null;
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _image,
                  decoration: const InputDecoration(
                      labelText: 'Image URL (optional)'),
                  keyboardType: TextInputType.url,
                  validator: (v) {
                    final s = v?.trim() ?? '';
                    return (s.isNotEmpty && !s.startsWith('http'))
                        ? 'Must start with http:// or https://'
                        : null;
                  },
                ),
                const SizedBox(height: 24),
                FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: _saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.save),
                  label: Text(_isEdit ? 'Save changes' : 'Add product'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
