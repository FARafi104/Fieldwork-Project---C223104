import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../data/model/product.dart';
import '../../providers/product_provider.dart';
import '../../providers/theme_provider.dart';
import '../widgets/product_card.dart';
import '../widgets/state_views.dart';
import 'detail_screen.dart';
import 'product_form_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _scroll = ScrollController();
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scroll.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  // Infinite scrolling: load the next page near the bottom.
  void _onScroll() {
    if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 300) {
      context.read<ProductProvider>().loadMore();
    }
  }

  void _openDetail(Product product) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => DetailScreen(product: product)),
    );
  }

  void _openForm() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const ProductFormScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<ProductProvider>();
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        actions: [
          IconButton(
            tooltip: 'Favorites only',
            onPressed: p.toggleFavoritesOnly,
            icon: Icon(p.favoritesOnly ? Icons.favorite : Icons.favorite_border),
          ),
          PopupMenuButton<SortOption>(
            tooltip: 'Sort',
            icon: const Icon(Icons.sort),
            onSelected: p.setSort,
            itemBuilder: (_) => [
              for (final o in SortOption.values)
                CheckedPopupMenuItem(
                  value: o,
                  checked: p.sort == o,
                  child: Text(o.label),
                ),
            ],
          ),
          IconButton(
            tooltip: 'Toggle dark mode',
            onPressed: theme.toggle,
            icon: Icon(theme.isDark ? Icons.light_mode : Icons.dark_mode),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openForm,
        icon: const Icon(Icons.add),
        label: const Text('Add'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            child: TextField(
              controller: _searchCtrl,
              textInputAction: TextInputAction.search,
              onChanged: (v) {
                setState(() {});
                p.onQueryChanged(v);
              },
              decoration: InputDecoration(
                hintText: 'Search products...',
                prefixIcon: const Icon(Icons.search),
                isDense: true,
                suffixIcon: _searchCtrl.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() {});
                          p.onQueryChanged('');
                        },
                      ),
              ),
            ),
          ),
          if (p.fromCache) const _OfflineBanner(),
          Expanded(child: _buildBody(p)),
        ],
      ),
    );
  }

  Widget _buildBody(ProductProvider p) {
    switch (p.status) {
      case LoadStatus.loading:
        return const LoadingView();
      case LoadStatus.error:
        return ErrorView(
          message: p.error ?? 'Something went wrong.',
          onRetry: () => p.loadInitial(),
        );
      case LoadStatus.loaded:
        final items = p.visibleItems;
        if (items.isEmpty) {
          return RefreshIndicator(
            onRefresh: p.refresh,
            child: EmptyView(
              title: p.favoritesOnly ? 'No favorites yet' : 'No products found',
              message: p.favoritesOnly
                  ? 'Tap the heart on a product to save it here.'
                  : (p.query.isEmpty
                      ? 'Pull down to refresh or add a new product.'
                      : 'Nothing matches "${p.query}". Try another search.'),
            ),
          );
        }
        return RefreshIndicator(
          onRefresh: p.refresh,
          child: LayoutBuilder(builder: (context, box) {
            // Responsive: 1 column on phones, 2-3 on tablets.
            final cols = box.maxWidth >= 900 ? 3 : (box.maxWidth >= 600 ? 2 : 1);
            return CustomScrollView(
              controller: _scroll,
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  sliver: SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: cols,
                      mainAxisExtent: ProductCard.height,
                      mainAxisSpacing: 8,
                      crossAxisSpacing: 8,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, i) {
                        final item = items[i];
                        return ProductCard(
                          product: item,
                          isFavorite: p.isFavorite(item.id),
                          onTap: () => _openDetail(item),
                          onFavorite: () => p.toggleFavorite(item.id),
                        );
                      },
                      childCount: items.length,
                    ),
                  ),
                ),
                SliverToBoxAdapter(child: _Footer(provider: p)),
              ],
            );
          }),
        );
    }
  }
}

class _Footer extends StatelessWidget {
  const _Footer({required this.provider});

  final ProductProvider provider;

  @override
  Widget build(BuildContext context) {
    Widget child;
    if (provider.isLoadingMore) {
      child = const Center(child: CircularProgressIndicator());
    } else if (provider.loadMoreError) {
      child = Center(
        child: TextButton.icon(
          onPressed: provider.loadMore,
          icon: const Icon(Icons.refresh),
          label: const Text("Couldn't load more. Tap to retry"),
        ),
      );
    } else if (provider.hasMore) {
      child = Center(
        child: OutlinedButton(
          onPressed: provider.loadMore,
          child: const Text('Load more'),
        ),
      );
    } else {
      child = Center(
        child: Text("You've reached the end",
            style: Theme.of(context).textTheme.bodySmall),
      );
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 16, 12, 96),
      child: child,
    );
  }
}

class _OfflineBanner extends StatelessWidget {
  const _OfflineBanner();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      color: scheme.tertiaryContainer,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        children: [
          Icon(Icons.wifi_off, size: 16, color: scheme.onTertiaryContainer),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Offline mode - showing saved data',
              style: TextStyle(color: scheme.onTertiaryContainer),
            ),
          ),
        ],
      ),
    );
  }
}
