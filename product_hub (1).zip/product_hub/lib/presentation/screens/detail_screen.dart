import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/model/product.dart';
import '../../providers/product_provider.dart';
import '../widgets/product_image.dart';
import 'product_form_screen.dart';

class DetailScreen extends StatefulWidget {
  const DetailScreen({super.key, required this.product});

  final Product product;

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  late Product _product = widget.product;

  Future<void> _edit() async {
    final updated = await Navigator.of(context).push<Product>(
      MaterialPageRoute(builder: (_) => ProductFormScreen(product: _product)),
    );
    if (updated != null && mounted) setState(() => _product = updated);
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete product?'),
        content: Text('"${_product.title}" will be removed.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Delete')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    await context.read<ProductProvider>().deleteProduct(_product);
    navigator.pop();
    messenger.showSnackBar(const SnackBar(content: Text('Product deleted')));
  }

  @override
  Widget build(BuildContext context) {
    final p = _product;
    final provider = context.watch<ProductProvider>();
    final isFav = provider.isFavorite(p.id);

    return Scaffold(
      appBar: AppBar(
        title: Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'Favorite',
            onPressed: () => provider.toggleFavorite(p.id),
            icon: Icon(isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? Colors.redAccent : null),
          ),
          IconButton(
              tooltip: 'Edit', onPressed: _edit, icon: const Icon(Icons.edit)),
          IconButton(
              tooltip: 'Delete',
              onPressed: _delete,
              icon: const Icon(Icons.delete_outline)),
        ],
      ),
      body: LayoutBuilder(builder: (context, box) {
        final gallery = _Gallery(images: p.allImages);
        final info = _Info(product: p);
        if (box.maxWidth >= 700) {
          // Tablet: gallery and details side by side.
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16), child: gallery),
              ),
              Expanded(
                child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16), child: info),
              ),
            ],
          );
        }
        return SingleChildScrollView(
          child: Column(
            children: [
              Padding(padding: const EdgeInsets.all(12), child: gallery),
              Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                  child: info),
            ],
          ),
        );
      }),
    );
  }
}

class _Gallery extends StatefulWidget {
  const _Gallery({required this.images});

  final List<String> images;

  @override
  State<_Gallery> createState() => _GalleryState();
}

class _GalleryState extends State<_Gallery> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      children: [
        AspectRatio(
          aspectRatio: 1.15,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: widget.images.isEmpty
                ? const ProductImage(url: '')
                : PageView.builder(
                    itemCount: widget.images.length,
                    onPageChanged: (i) => setState(() => _index = i),
                    itemBuilder: (_, i) => ProductImage(
                        url: widget.images[i], fit: BoxFit.contain),
                  ),
          ),
        ),
        if (widget.images.length > 1)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < widget.images.length; i++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: i == _index ? 18 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: i == _index ? scheme.primary : scheme.outlineVariant,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

class _Info extends StatelessWidget {
  const _Info({required this.product});

  final Product product;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = product;
    final rows = <(String, String)>[
      ('Stock', '${p.stock}'),
      if (p.sku.isNotEmpty) ('SKU', p.sku),
      if (p.weight != null) ('Weight', '${p.weight}'),
      if (p.availability.isNotEmpty) ('Availability', p.availability),
      if (p.warranty.isNotEmpty) ('Warranty', p.warranty),
      if (p.shipping.isNotEmpty) ('Shipping', p.shipping),
      if (p.returnPolicy.isNotEmpty) ('Returns', p.returnPolicy),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(p.title,
            style: theme.textTheme.headlineSmall
                ?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text('\$${p.discountedPrice.toStringAsFixed(2)}',
                style: theme.textTheme.headlineSmall?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.bold)),
            if (p.discountPercentage > 0) ...[
              const SizedBox(width: 10),
              Text('\$${p.price.toStringAsFixed(2)}',
                  style: theme.textTheme.bodyMedium
                      ?.copyWith(decoration: TextDecoration.lineThrough)),
              const SizedBox(width: 10),
              Chip(
                label: Text('-${p.discountPercentage.toStringAsFixed(0)}%'),
                visualDensity: VisualDensity.compact,
              ),
            ],
          ],
        ),
        const SizedBox(height: 8),
        Row(children: [
          const Icon(Icons.star_rounded, color: Colors.amber),
          const SizedBox(width: 4),
          Text(p.rating.toStringAsFixed(1), style: theme.textTheme.titleMedium),
          if (p.isLocal) ...[
            const SizedBox(width: 12),
            const Chip(
              avatar: Icon(Icons.phone_android, size: 16),
              label: Text('Added on this device'),
              visualDensity: VisualDensity.compact,
            ),
          ],
        ]),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            if (p.category.isNotEmpty) Chip(label: Text(p.category)),
            if (p.brand.isNotEmpty) Chip(label: Text(p.brand)),
            for (final t in p.tags) Chip(label: Text('#$t')),
          ],
        ),
        const SizedBox(height: 12),
        Text('Description', style: theme.textTheme.titleMedium),
        const SizedBox(height: 4),
        Text(p.description),
        const SizedBox(height: 16),
        Text('Details', style: theme.textTheme.titleMedium),
        const SizedBox(height: 4),
        for (final r in rows)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                    width: 110,
                    child: Text(r.$1,
                        style: TextStyle(color: theme.colorScheme.outline))),
                Expanded(child: Text(r.$2)),
              ],
            ),
          ),
        if (p.reviews.isNotEmpty) ...[
          const SizedBox(height: 16),
          Text('Reviews (${p.reviews.length})',
              style: theme.textTheme.titleMedium),
          const SizedBox(height: 4),
          for (final r in p.reviews)
            Card(
              margin: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                title: Text('${r['reviewerName'] ?? 'Anonymous'}'),
                subtitle: Text('${r['comment'] ?? ''}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.star_rounded,
                        size: 18, color: Colors.amber),
                    Text('${r['rating'] ?? ''}'),
                  ],
                ),
              ),
            ),
        ],
      ],
    );
  }
}
