import 'package:flutter/material.dart';

import '../data/datasource/local_datasource.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeProvider(this._local) : _isDark = _local.isDark;

  final LocalDataSource _local;
  bool _isDark;

  bool get isDark => _isDark;
  ThemeMode get mode => _isDark ? ThemeMode.dark : ThemeMode.light;

  Future<void> toggle() async {
    _isDark = !_isDark;
    notifyListeners();
    await _local.saveDark(_isDark);
  }
}
