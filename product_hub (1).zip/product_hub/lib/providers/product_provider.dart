import 'package:flutter/foundation.dart';

import '../core/app_exception.dart';
import '../core/constants.dart';
import '../data/model/product.dart';
import '../data/repository/product_repository.dart';
import '../services/debouncer.dart';

enum LoadStatus { loading, loaded, error }

enum SortOption {
  none('Default'),
  priceLow('Price: low to high'),
  priceHigh('Price: high to low'),
  rating('Top rated'),
  titleAz('Title: A to Z');

  const SortOption(this.label);
  final String label;
}

class ProductProvider extends ChangeNotifier {
  ProductProvider(this._repo) : _favorites = _repo.favorites {
    loadInitial();
  }

  final ProductRepository _repo;
  final _debouncer = Debouncer(const Duration(milliseconds: 500));

  List<Product> _items = [];
  Set<int> _favorites;
  LoadStatus _status = LoadStatus.loading;
  String? _error;
  String _query = '';
  SortOption _sort = SortOption.none;
  bool _favoritesOnly = false;

  int _nextSkip = 0;
  bool _hasMore = false;
  bool _isLoadingMore = false;
  bool _loadMoreError = false;
  bool _fromCache = false;
  int _requestId = 0; // ignores stale responses (fast typing)

  // ---- getters ----
  LoadStatus get status => _status;
  String? get error => _error;
  bool get hasMore => _hasMore;
  bool get isLoadingMore => _isLoadingMore;
  bool get loadMoreError => _loadMoreError;
  bool get fromCache => _fromCache;
  SortOption get sort => _sort;
  bool get favoritesOnly => _favoritesOnly;
  String get query => _query;

  bool isFavorite(int id) => _favorites.contains(id);

  /// Items after applying the favorites filter and sorting.
  List<Product> get visibleItems {
    final list = _favoritesOnly
        ? _items.where((p) => _favorites.contains(p.id)).toList()
        : List<Product>.of(_items);
    switch (_sort) {
      case SortOption.priceLow:
        list.sort((a, b) => a.price.compareTo(b.price));
      case SortOption.priceHigh:
        list.sort((a, b) => b.price.compareTo(a.price));
      case SortOption.rating:
        list.sort((a, b) => b.rating.compareTo(a.rating));
      case SortOption.titleAz:
        list.sort(
            (a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
      case SortOption.none:
        break;
    }
    return list;
  }

  // ---- loading ----
  Future<void> loadInitial({bool silent = false}) async {
    final id = ++_requestId;
    if (!silent) {
      _status = LoadStatus.loading;
      notifyListeners();
    }
    try {
      final page = await _repo.getProducts(
        skip: 0,
        limit: AppConstants.pageSize,
        query: _query,
      );
      if (id != _requestId) return;
      _items = page.items;
      _nextSkip = page.nextSkip;
      _hasMore = page.hasMore;
      _fromCache = page.fromCache;
      _status = LoadStatus.loaded;
      _error = null;
    } on AppException catch (e) {
      if (id != _requestId) return;
      _status = LoadStatus.error;
      _error = e.message;
    } catch (_) {
      if (id != _requestId) return;
      _status = LoadStatus.error;
      _error = 'Something went wrong. Please try again.';
    }
    _isLoadingMore = false;
    _loadMoreError = false;
    notifyListeners();
  }

  /// Pull-to-refresh.
  Future<void> refresh() => loadInitial(silent: true);

  Future<void> loadMore() async {
    if (_isLoadingMore || !_hasMore || _status != LoadStatus.loaded) return;
    final id = _requestId;
    _isLoadingMore = true;
    _loadMoreError = false;
    notifyListeners();
    try {
      final page = await _repo.getProducts(
        skip: _nextSkip,
        limit: AppConstants.pageSize,
        query: _query,
      );
      if (id != _requestId) return;
      final existing = _items.map((p) => p.id).toSet();
      _items = [..._items, ...page.items.where((p) => !existing.contains(p.id))];
      _nextSkip = page.nextSkip;
      _hasMore = page.hasMore;
      _fromCache = page.fromCache;
    } catch (_) {
      if (id == _requestId) _loadMoreError = true;
    }
    if (id == _requestId) {
      _isLoadingMore = false;
      notifyListeners();
    }
  }

  // ---- search / sort / filter ----
  void onQueryChanged(String value) {
    _debouncer.run(() {
      final q = value.trim();
      if (q == _query) return;
      _query = q;
      loadInitial();
    });
  }

  void setSort(SortOption option) {
    _sort = option;
    notifyListeners();
  }

  void toggleFavoritesOnly() {
    _favoritesOnly = !_favoritesOnly;
    notifyListeners();
  }

  Future<void> toggleFavorite(int id) async {
    _favorites = {..._favorites};
    if (!_favorites.remove(id)) _favorites.add(id);
    notifyListeners();
    await _repo.saveFavorites(_favorites);
  }

  // ---- CRUD ----
  Future<void> addProduct(Product p) async {
    await _repo.create(p);
    _items = [p, ..._items];
    notifyListeners();
  }

  Future<void> updateProduct(Product p) async {
    await _repo.update(p);
    _items = [for (final i in _items) i.id == p.id ? p : i];
    notifyListeners();
  }

  Future<void> deleteProduct(Product p) async {
    await _repo.delete(p);
    _items = _items.where((i) => i.id != p.id).toList();
    _favorites = {..._favorites}..remove(p.id);
    notifyListeners();
    await _repo.saveFavorites(_favorites);
  }

  @override
  void dispose() {
    _debouncer.dispose();
    super.dispose();
  }
}
