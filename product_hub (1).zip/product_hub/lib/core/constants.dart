class AppConstants {
  static const appName = 'Product Hub';
  static const baseUrl = 'https://dummyjson.com';
  static const pageSize = 20;
}
