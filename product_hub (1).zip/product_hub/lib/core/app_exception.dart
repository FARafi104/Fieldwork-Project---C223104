import 'dart:io';

import 'package:dio/dio.dart';

/// Friendly error shown in the UI.
class AppException implements Exception {
  AppException(this.message);
  final String message;

  factory AppException.fromDio(DioException e) {
    const offline =
        'No internet connection. Please check your network and try again.';
    switch (e.type) {
      case DioExceptionType.connectionError:
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return AppException(offline);
      case DioExceptionType.badResponse:
        return AppException(
            'Server error (${e.response?.statusCode}). Please try again later.');
      default:
        if (e.error is SocketException) return AppException(offline);
        return AppException('Something went wrong. Please try again.');
    }
  }

  @override
  String toString() => message;
}
