import 'product.dart';

/// One page of results returned by the repository.
class ProductPage {
  const ProductPage({
    required this.items,
    required this.nextSkip,
    required this.hasMore,
    required this.fromCache,
  });

  final List<Product> items;
  final int nextSkip;
  final bool hasMore;
  final bool fromCache;
}
