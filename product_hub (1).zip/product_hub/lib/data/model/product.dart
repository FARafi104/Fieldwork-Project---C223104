class Product {
  const Product({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.price,
    this.discountPercentage = 0,
    this.rating = 0,
    this.stock = 0,
    this.brand = '',
    this.thumbnail = '',
    this.images = const [],
    this.tags = const [],
    this.sku = '',
    this.weight,
    this.warranty = '',
    this.shipping = '',
    this.availability = '',
    this.returnPolicy = '',
    this.reviews = const [],
    this.isLocal = false,
    this.isEdited = false,
  });

  final int id;
  final String title;
  final String description;
  final String category;
  final double price;
  final double discountPercentage;
  final double rating;
  final int stock;
  final String brand;
  final String thumbnail;
  final List<String> images;
  final List<String> tags;
  final String sku;
  final double? weight;
  final String warranty;
  final String shipping;
  final String availability;
  final String returnPolicy;
  final List<Map<String, dynamic>> reviews;

  /// Created in the app (does not exist on the server).
  final bool isLocal;

  /// Modified by the user; the local version wins over server data.
  final bool isEdited;

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: (json['id'] as num).toInt(),
      title: (json['title'] ?? '') as String,
      description: (json['description'] ?? '') as String,
      category: (json['category'] ?? '') as String,
      price: (json['price'] as num?)?.toDouble() ?? 0,
      discountPercentage: (json['discountPercentage'] as num?)?.toDouble() ?? 0,
      rating: (json['rating'] as num?)?.toDouble() ?? 0,
      stock: (json['stock'] as num?)?.toInt() ?? 0,
      brand: (json['brand'] ?? '') as String,
      thumbnail: (json['thumbnail'] ?? '') as String,
      images: List<String>.from(json['images'] as List? ?? const []),
      tags: List<String>.from(json['tags'] as List? ?? const []),
      sku: (json['sku'] ?? '') as String,
      weight: (json['weight'] as num?)?.toDouble(),
      warranty: (json['warrantyInformation'] ?? '') as String,
      shipping: (json['shippingInformation'] ?? '') as String,
      availability: (json['availabilityStatus'] ?? '') as String,
      returnPolicy: (json['returnPolicy'] ?? '') as String,
      reviews: (json['reviews'] as List? ?? const [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList(),
      isLocal: json['isLocal'] as bool? ?? false,
      isEdited: json['isEdited'] as bool? ?? false,
    );
  }

  /// Used for the local cache (includes app-only flags).
  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'category': category,
        'price': price,
        'discountPercentage': discountPercentage,
        'rating': rating,
        'stock': stock,
        'brand': brand,
        'thumbnail': thumbnail,
        'images': images,
        'tags': tags,
        'sku': sku,
        'weight': weight,
        'warrantyInformation': warranty,
        'shippingInformation': shipping,
        'availabilityStatus': availability,
        'returnPolicy': returnPolicy,
        'reviews': reviews,
        'isLocal': isLocal,
        'isEdited': isEdited,
      };

  /// Body sent to the API for create / update.
  Map<String, dynamic> toApiBody() => {
        'title': title,
        'description': description,
        'category': category,
        'brand': brand,
        'price': price,
        'stock': stock,
        'thumbnail': thumbnail,
      };

  Product copyWith({
    String? title,
    String? description,
    String? category,
    String? brand,
    double? price,
    int? stock,
    String? thumbnail,
    List<String>? images,
    bool? isEdited,
  }) {
    return Product(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      price: price ?? this.price,
      discountPercentage: discountPercentage,
      rating: rating,
      stock: stock ?? this.stock,
      brand: brand ?? this.brand,
      thumbnail: thumbnail ?? this.thumbnail,
      images: images ?? this.images,
      tags: tags,
      sku: sku,
      weight: weight,
      warranty: warranty,
      shipping: shipping,
      availability: availability,
      returnPolicy: returnPolicy,
      reviews: reviews,
      isLocal: isLocal,
      isEdited: isEdited ?? this.isEdited,
    );
  }

  List<String> get allImages => images.isNotEmpty
      ? images
      : (thumbnail.isNotEmpty ? [thumbnail] : const []);

  double get discountedPrice => price * (1 - discountPercentage / 100);
}
