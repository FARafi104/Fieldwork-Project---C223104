import 'package:dio/dio.dart';

import '../../core/constants.dart';
import '../model/product.dart';

/// Talks to https://dummyjson.com
class RemoteDataSource {
  RemoteDataSource({Dio? dio})
      : _dio = dio ??
            Dio(BaseOptions(
              baseUrl: AppConstants.baseUrl,
              connectTimeout: const Duration(seconds: 10),
              receiveTimeout: const Duration(seconds: 10),
            ));

  final Dio _dio;

  Future<({List<Product> items, int total})> fetchProducts({
    required int skip,
    required int limit,
    String query = '',
  }) async {
    final res = await _dio.get(
      query.isEmpty ? '/products' : '/products/search',
      queryParameters: {
        'limit': limit,
        'skip': skip,
        if (query.isNotEmpty) 'q': query,
      },
    );
    final data = res.data as Map<String, dynamic>;
    final items = (data['products'] as List)
        .map((e) => Product.fromJson(e as Map<String, dynamic>))
        .toList();
    return (items: items, total: (data['total'] as num).toInt());
  }

  Future<void> createProduct(Product p) =>
      _dio.post('/products/add', data: p.toApiBody());

  Future<void> updateProduct(Product p) =>
      _dio.put('/products/${p.id}', data: p.toApiBody());

  Future<void> deleteProduct(int id) => _dio.delete('/products/$id');
}
