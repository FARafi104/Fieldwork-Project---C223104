import 'dart:convert';

import 'package:hive_flutter/hive_flutter.dart';

import '../model/product.dart';

/// Hive-backed cache. Products are stored as JSON strings so no
/// code generation (build_runner) is needed.
class LocalDataSource {
  late final Box<String> _products;
  late final Box<bool> _deleted;
  late final Box _settings;

  Future<void> init() async {
    await Hive.initFlutter();
    _products = await Hive.openBox<String>('products');
    _deleted = await Hive.openBox<bool>('deleted_ids');
    _settings = await Hive.openBox('settings');
  }

  Product _decode(String s) =>
      Product.fromJson(jsonDecode(s) as Map<String, dynamic>);

  List<Product> getAll() => _products.values.map(_decode).toList();

  Product? get(int id) {
    final s = _products.get('$id');
    return s == null ? null : _decode(s);
  }

  Future<void> put(Product p) => _products.put('${p.id}', jsonEncode(p.toJson()));

  Future<void> putAll(List<Product> list) => _products.putAll({
        for (final p in list) '${p.id}': jsonEncode(p.toJson()),
      });

  /// Removes the product and remembers the id so refreshes don't bring it back.
  Future<void> delete(int id) async {
    await _products.delete('$id');
    await _deleted.put('$id', true);
  }

  bool isDeleted(int id) => _deleted.containsKey('$id');

  // ---- settings ----
  Set<int> get favorites =>
      (_settings.get('favorites', defaultValue: <int>[]) as List)
          .cast<int>()
          .toSet();

  Future<void> saveFavorites(Set<int> ids) =>
      _settings.put('favorites', ids.toList());

  bool get isDark => _settings.get('dark', defaultValue: false) as bool;

  Future<void> saveDark(bool value) => _settings.put('dark', value);
}
