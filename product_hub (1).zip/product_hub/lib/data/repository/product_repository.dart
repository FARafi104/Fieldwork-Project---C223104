import 'package:dio/dio.dart';

import '../../core/app_exception.dart';
import '../datasource/local_datasource.dart';
import '../datasource/remote_datasource.dart';
import '../model/product.dart';
import '../model/product_page.dart';

/// Single source of truth for the UI.
///
/// Online  -> fetch from API, merge with local edits, refresh the cache.
/// Offline -> serve (and paginate / search) the cached data locally.
///
/// DummyJSON accepts POST/PUT/DELETE but only *simulates* them (nothing is
/// stored server-side), so the local cache is the real store for CRUD.
class ProductRepository {
  ProductRepository({
    required RemoteDataSource remote,
    required LocalDataSource local,
  })  : _remote = remote,
        _local = local;

  final RemoteDataSource _remote;
  final LocalDataSource _local;

  Set<int> get favorites => _local.favorites;
  Future<void> saveFavorites(Set<int> ids) => _local.saveFavorites(ids);

  Future<ProductPage> getProducts({
    required int skip,
    required int limit,
    String query = '',
  }) async {
    try {
      final remote =
          await _remote.fetchProducts(skip: skip, limit: limit, query: query);

      final merged = <Product>[];
      final toCache = <Product>[];
      for (final p in remote.items) {
        if (_local.isDeleted(p.id)) continue;
        final cached = _local.get(p.id);
        if (cached != null && cached.isEdited) {
          merged.add(cached); // keep the user's edits
        } else {
          merged.add(p);
          toCache.add(p);
        }
      }
      await _local.putAll(toCache);

      var items = merged;
      if (skip == 0) {
        final locals = _local
            .getAll()
            .where((p) => p.isLocal && _matches(p, query))
            .toList()
          ..sort((a, b) => a.id.compareTo(b.id));
        items = [...locals, ...merged];
      }

      final nextSkip = skip + remote.items.length;
      return ProductPage(
        items: items,
        nextSkip: nextSkip,
        hasMore: nextSkip < remote.total,
        fromCache: false,
      );
    } catch (e) {
      // Offline / API failure -> fall back to cache.
      final all = _local.getAll();
      if (all.isEmpty) {
        throw e is DioException
            ? AppException.fromDio(e)
            : AppException('Unexpected response from the server.');
      }
      final cached = all.where((p) => _matches(p, query)).toList()
        ..sort((a, b) => a.id.compareTo(b.id)); // local (negative ids) first
      final page = cached.skip(skip).take(limit).toList(); // local pagination
      final nextSkip = skip + page.length;
      return ProductPage(
        items: page,
        nextSkip: nextSkip,
        hasMore: nextSkip < cached.length,
        fromCache: true,
      );
    }
  }

  Future<void> create(Product p) async {
    try {
      await _remote.createProduct(p);
    } on DioException catch (_) {
      // Offline: the local copy below is enough.
    }
    await _local.put(p);
  }

  Future<void> update(Product p) async {
    if (!p.isLocal) {
      try {
        await _remote.updateProduct(p);
      } on DioException catch (_) {}
    }
    await _local.put(p);
  }

  Future<void> delete(Product p) async {
    if (!p.isLocal) {
      try {
        await _remote.deleteProduct(p.id);
      } on DioException catch (_) {}
    }
    await _local.delete(p.id);
  }

  bool _matches(Product p, String query) {
    if (query.isEmpty) return true;
    final q = query.toLowerCase();
    return p.title.toLowerCase().contains(q) ||
        p.description.toLowerCase().contains(q) ||
        p.category.toLowerCase().contains(q) ||
        p.brand.toLowerCase().contains(q);
  }
}
